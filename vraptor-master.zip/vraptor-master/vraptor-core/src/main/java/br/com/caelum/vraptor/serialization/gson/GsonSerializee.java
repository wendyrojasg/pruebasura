package br.com.caelum.vraptor.serialization.gson;

import br.com.caelum.vraptor.ioc.Component;
import br.com.caelum.vraptor.serialization.xstream.Serializee;

@Component
public class GsonSerializee extends Serializee {

}
